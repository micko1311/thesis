<?php
include 'conn.php';

if(isset($_POST['submit'])) {
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    $rsbsa_num = mysqli_real_escape_string($conn, $_POST['rsbsa_num']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $area = mysqli_real_escape_string($conn, $_POST['area']);
    $barangay = mysqli_real_escape_string($conn, $_POST['barangay']);
    $contact = mysqli_real_escape_string($conn, $_POST['contact']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM `farmertbl` WHERE rsbsa_num='$rsbsa_num'";
    $result = $conn->query($sql);

    if($result->num_rows > 0){
        echo "<script>alert('Username already taken');</script>";
    }else{
        $sql= "INSERT INTO `farmertbl` (id, rsbsa_num, name, area, barangay, contact, password) VALUES ('$id', '$rsbsa_num', '$name', '$area', '$barangay', '$contact', '$password')";
        if ($conn->query($sql) === TRUE) {
            header('location:farmers.php?signup=success');
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    
}
