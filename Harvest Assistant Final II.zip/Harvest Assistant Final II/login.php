<?php
    include 'conn.php';

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $username = htmlspecialchars($_POST['username']);
        $password = htmlspecialchars($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM admintbl WHERE BINARY username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        
        if (password_verify($password, $row['password'])) {
            header("Location: index.php?login=success");
            exit();
        } else {
            echo "<script>alert('Invalid username or password. Please try again.');</script>";
        }
    } else {
        echo "<script>alert('Invalid username or password. Please try again.');</script>";
    }

    $stmt->close();
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harvest Assistant</title>
    <link rel="icon" type="img/jpg" href="assets/images/logo.png">
    <link rel="stylesheet" href="assets/css/login.css?v=1">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <style>
        body{
            background-image: url("assets/images/bg.jpg");
        }
    </style>
</head>
<body>
    <div class="wrap">
        <form action="login.php" method="post" >
            <h1>Login</h1>
            <div class="input">
                <input type="text" placeholder="Username" name="username" required>
                <i class='bx bx-user'></i>
            </div>

            <div class="input">
                <input type="password" placeholder="Password" name="password"  required>
                <i class='bx bx-lock-alt'></i>
            </div>

            <div class="rec-rem">
                <label><input type="checkbox" name="" id="">Remember me</label>
                <a href="">Forgot password?</a>
            </div>

            <button type="submit" name="save" class="btnlogin" >Login</button>

            <div class="register">
                <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            </div>

        </form>
    </div>

    <script>
        <?php
        if(isset($_GET['signup']) && $_GET['signup'] == "success") {
            echo "alert('Signed up successfully');";
        }
        ?>
    </script>

</body>
</html>