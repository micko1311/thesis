<?php
    include 'conn.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Harvest Assistant</title>
    <link rel="icon" type="jpg/pngs" href="assets/images/logo.png">
    <link rel="stylesheet" href="assets/css/farmers.css?v=3">
    <link rel= "stylesheet" href= "https://maxst.icons8.com/vue-static/landings/line-awesome/line-awesome/1.3.0/css/line-awesome.min.css" >
    <style>
.update{
    height: 1.5rem;
    padding: 0 4px 0;
    border: none;
    outline: none;
    border-radius: 5px;
    background: green;
    cursor: pointer;
}
.delete{
    height: 1.5rem;
    padding: 0 4px 0;
    border: none;
    outline: none;
    border-radius: 5px;
    background: red;
    cursor: pointer;
}
.updel{
    color: white;
}
</style>
</head>
<body>
    
    <div class="container">

        <div class="sidebar">
            <ul>
                <li>
                    <a href="">
                        <span class="icon" ><ion-icon name="leaf-outline"></ion-icon></span>
                        <span class="title" >Harvest Assistant</span>
                    </a>
                </li>

                <li>
                    <a href="index.php">
                        <span class="icon" ><ion-icon name="home-outline" ></ion-icon></span>
                        <span class="title" >Dashboard</span>
                    </a>
                    <span class="htitle" >Dashboard</span>
                </li>

                <li>
                    <a href="farmers.php">
                        <span class="icon" ><ion-icon name="people-outline"></ion-icon></span>
                        <span class="title" >Farmers</span>
                    </a>
                    <span class="htitle" >Farmers</span>
                </li>
                
                <li>
                    <a href="analytics.php">
                        <span class="icon" ><ion-icon name="bar-chart-outline"></ion-icon></span>
                        <span class="title" >Analytics</span>
                    </a>
                    <span class="htitle" >Analytics</span>
                </li>

                <li>
                    <a href="report.php">
                        <span class="icon" ><ion-icon name="alert-circle-outline"></ion-icon></span>
                        <span class="title" >Report</span>
                    </a>
                    <span class="htitle" >Report</span>
                </li>

                <li>
                    <a href="messages.php">
                        <span class="icon" ><ion-icon name="chatbubble-outline"></ion-icon></span>
                        <span class="title" >Messages</span>
                    </a>
                    <span class="htitle" >Messages</span>
                </li>

                <li>
                    <a href="logout.php">
                        <span class="icon" ><ion-icon name="log-out-outline"></ion-icon></span>
                        <span class="title" >Sign Out</span>
                    </a>
                    <span class="htitle" >Sign Out</span>
                </li>

            </ul>
        </div>
        

        <div class="main">
            <div class="topbar">
                <div class="toggle"><ion-icon name="menu-outline"></ion-icon></div>
                
                <div class="search">
                    <label>
                        <input type="text" id="searchinput" placeholder="Search" >
                        <ion-icon name="search-outline"></ion-icon>
                    </label>
                </div>       

                <div class="user">

                    <div class="topicon">
                        <span><ion-icon name="chatbubbles-outline"></ion-icon></span>
                        <span><ion-icon name="notifications-outline"></ion-icon></span>
                    </div>

                    <img src="assets/images/pfp.jpg" alt="">
                        <div class="userdes">
                            <p>Emerson Alvarado</p>
                            <small>Admin</small>
                        </div>
                </div>
            </div>
            
            <!-- ================ Hrvest Details List ================= -->
            <div class="details">
                <div class="farmerlist">
                    <div class="cardheader">
                        <h2>Farmers' Information</h2>
                    </div>   
                        <i class="las la-user-plus addicon" onclick="popup()"></i>
                    <div id="popupid" class="popup">

                        <div class="popup-content">
                            <span class="close" onclick="closepopup()" >&times;</span>
                            <h3>Add New Farmer</h3>

                            <form action="addfarmer.php" method="POST">
                                <label class="lbl" for="rsbsanumber">RSBSA Number</label>
                                <input class="inp" type="text" id="rsbsa_num" name="rsbsa_num"  placeholder="" required>

                                <label class="lbl" for="Name">Name</label>
                                <input class="inp" type="text" id="name" name="name" placeholder="" required>

                                <label class="lbl" for="area">Area</label>
                                <input class="inp" type="text" id="area" name="area" placeholder="" required>

                                <label class="lbl" for="barangay">Barangay</label>
                                <input class="inp" type="text" id="barangay" name="barangay" placeholder="" required>

                                <label class="lbl" for="contact">Contact</label>
                                <input class="inp" type="phone" id="contact" name="contact" placeholder="" required>

                                <label class="lbl" for="password">Password</label>
                                <input class="inp" type="password" id="password" name="password" placeholder="" required>

                                <button class="addfarmer" name="submit" type="submit">Add</button>
                            </form>
                        </div>

                    </div>

                    <script>
                        var modal = document.getElementById("popupid");

                        function popup() {
                        modal.style.display = "block";
                        }

                        function closepopup() {
                        modal.style.display = "none";
                        }

                        window.onclick = function(event) {
                        if (event.target == modal) {
                            modal.style.display = "none";
                        }
                        }
                        </script>

                        <table>
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>RSBSA Number</th>
                                <th>Name</th>
                                <th>Area</th>
                                <th>Barangay</th>
                                <th>Contact</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                                   
                            $sql = "SELECT * FROM `farmertbl`"; 
                            $result=mysqli_query($conn,$sql);

                            if ($result) {                
                                while($row =mysqli_fetch_assoc($result)) {
                                    $id=$row['id'];
                                    $rsbsa_num=$row['rsbsa_num'];
                                    $name=$row['name'];
                                    $area=$row['area'];
                                    $barangay=$row['barangay'];
                                    $contact=$row['contact'];

                                    echo "
                                    <tr>
                                            <td>$id</td>
                                            <td>$rsbsa_num</td>
                                            <td>$name</td>
                                            <td>$area</td>
                                            <td>$barangay</td>
                                            <td>$contact</td>
                                            <td>
                                                <button class='update' ><a class='updel' href='update.php?updateid=".$id."' >Update</a></button>
                                                <button class='delete' ><a class='updel' href='delete.php?deleteid=".$id."'>Delete</a></button>
                                            </td>
                                    </tr>";
                                }
                            } else {
                                echo "0 results";
                            }


                            $conn->close();
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

            
            
        </div>
    </div>



    <script src="assets/js/main.js" ></script>

    <!-- ====== ionicons ======= -->
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>

</body>
</html>